let trees = [];
let barn;

function setup() {
  createCanvas(600, 400);
  // Criando o celeiro
  barn = new Building(500, 300, 80, 80, 'red');
}

function draw() {
  background(135, 206, 235); // Céu azul

  // Desenhar o chão
  fill(34, 139, 34);
  rect(0, height - 50, width, 50);

  // Desenhar o celeiro
  barn.display();

  // Desenhar as árvores
  for (let tree of trees) {
    tree.display();
  }
}

// Classe para árvores
class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  display() {
    // Tronco
    fill(139, 69, 19);
    rect(this.x, this.y - 20, 10, 20);
    // Folhagem
    fill(34, 139, 34);
    ellipse(this.x + 5, this.y - 30, 30, 30);
  }
}

// Classe para o celeiro
class Building {
  constructor(x, y, w, h, color) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.color = color;
  }

  display() {
    fill(this.color);
    rect(this.x, this.y - this.h, this.w, this.h);
    // Telhado
    fill(150, 75, 0);
    triangle(
      this.x, this.y - this.h,
      this.x + this.w / 2, this.y - this.h - 30,
      this.x + this.w, this.y - this.h
    );
  }
}

function mousePressed() {
  // Quando clicar, planta uma árvore na posição do mouse
  if (mouseY < height - 50) { // Evitar plantar no chão
    trees.push(new Tree(mouseX, height - 50));
  }
}